add-apt-repository cloud-archive:vistoria
add-apt-repository cloud-archive:victoria
apt update && apt dist-upgrade
apt update
apt dist-upgrade
apt install python3-openstackclient
git clone https://github.com/adamorucu/de2_project.git
cd de2_project/
source UPPMAX\ 2020_1-3-openrc.sh 
openstack server list
